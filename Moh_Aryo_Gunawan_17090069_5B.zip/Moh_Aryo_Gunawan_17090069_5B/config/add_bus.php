<?php

	include 'koneksi.php';
	$nama_bus	     		= $_POST["nama_bus"];
	$kelas	     		= $_POST["kelas"];
	$harga		    	= $_POST["harga"];
	$rute	     		= $_POST["rute"];
	$jadwal	     		= $_POST["jadwal"];

	$insert			= "INSERT INTO bus(nama_bus, kelas, harga, rute, jadwal) VALUES ('$nama_bus','$kelas','$harga','$rute','$jadwal')";

	$simpan			= mysqli_query($conn, $insert)or die(mysqli_error());

?>

<META HTTP-EQUIV="REFRESH" CONTENT = "0; URL=../admin/admin.php?halaman=manajemen_bus">